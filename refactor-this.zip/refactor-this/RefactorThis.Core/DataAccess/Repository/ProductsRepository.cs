﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RefactorThis.Core.DataAccess.Models;
using RefactorThis.Core.DataAccess.QueryHandler;
/// <summary>
/// Class to handle Product table and product option table sql insert/update/delete queries
/// </summary>

namespace RefactorThis.Core.DataAccess.Repository
{
    public class ProductsRepository : IProductsRepository
    {
        protected virtual SqlConnection GetDbConnection()
        {
            return DbHelpers.NewConnection();
        }
        public ErrorModel CreateProduct(Product product)
        {
            ErrorModel result = new ErrorModel { Code = 0, Message = "Success" };

            if (product != null)
            {
                try
                {
                    var conn = GetDbConnection();
                    var cmd = new SqlCommand($"insert into product (id, name, description, price, deliveryprice) values ('{Guid.NewGuid()}', '{product.Name}', '{product.Description}', {product.Price}, {product.DeliveryPrice})", conn);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
                catch(Exception ex)
                {
                    result.Code = 1;
                    result.Message = "Failed";
                    result.Description = ex.Message;
                }
            }
            else
            {
                result.Code = 2;
                result.Message = "Failed";
                result.Description = "Product data is null";
            }
            return result;

        }
        public ErrorModel UpdateProduct(Guid id, Product product)
        {
            ErrorModel result = new ErrorModel { Code = 0, Message = "Success" };

            if (product != null)
            {
                try
                {
                    var conn = GetDbConnection();                    
                    var cmd = new SqlCommand($"update product set name = '{product.Name}', description = '{product.Description}', price = {product.Price}, deliveryprice = {product.DeliveryPrice} where id = '{id}'", conn);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    result.Code = 1;
                    result.Message = "Failed";
                    result.Description = ex.Message;
                }
            }
            else
            {
                result.Code = 2;
                result.Message = "Failed";
                result.Description = "Product data is null";
            }

            return result;
        }
        public ErrorModel DeleteProduct(Guid id)
        {
            ErrorModel result = new ErrorModel { Code = 0, Message = "Success" };

            try
            {
                ProductsQueryHandler prodQuery = new ProductsQueryHandler();  
                
                foreach (var option in prodQuery.GetProductOptions(id).Items)
                    DeleteProductOption(option.Id);                

                var conn = DbHelpers.NewConnection();
                conn.Open();
                var cmd = new SqlCommand($"delete from product where id = '{id}'", conn);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                result.Code = 1;
                result.Message = "Failed";
                result.Description = ex.Message;
            }

            return result;
        }
        public ErrorModel CreateProductOption(Guid prodcutid, ProductOption productoption)
        {
            ErrorModel result = new ErrorModel { Code = 0, Message = "Success" };

            if (productoption != null)
            {
                try
                {
                    var conn = GetDbConnection();
                    var cmd = new SqlCommand($"insert into productoption (id, productid, name, description) values ('{Guid.NewGuid()}', '{prodcutid}', '{productoption.Name}', '{productoption.Description}')", conn);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    result.Code = 1;
                    result.Message = "Failed";
                    result.Description = ex.Message;
                }
            }
            else
            {
                result.Code = 2;
                result.Message = "Failed";
                result.Description = "Product option data is null";
            }
            return result;
        }

        public ErrorModel UpdateProductOption(Guid id, ProductOption productoption)
        {
            ErrorModel result = new ErrorModel { Code = 0, Message = "Success" };

            if (productoption != null)
            {
                try
                {
                    var conn = GetDbConnection();
                    var cmd = new SqlCommand($"update productoption set name = '{productoption.Name}', description = '{productoption.Description}' where id = '{id}'", conn);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    result.Code = 1;
                    result.Message = "Failed";
                    result.Description = ex.Message;
                }
            }
            else
            {
                result.Code = 2;
                result.Message = "Failed";
                result.Description = "Product option data is null";
            }

            return result;
        }

        public ErrorModel DeleteProductOption(Guid id)
        {
            ErrorModel result = new ErrorModel { Code = 0, Message = "Success" };

            try
            {
                var conn = DbHelpers.NewConnection();
                conn.Open();                
                var cmd = new SqlCommand($"delete from productoption where id = '{id}'", conn);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                result.Code = 1;
                result.Message = "Failed";
                result.Description = ex.Message;
            }

            return result;
        }
    }
}
