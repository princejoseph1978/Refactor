﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RefactorThis.Core.DataAccess.Models;

namespace RefactorThis.Core.DataAccess.Repository
{
    public interface IProductsRepository
    {
        ErrorModel CreateProduct(Product product);
        ErrorModel UpdateProduct(Guid id, Product product);
        ErrorModel DeleteProduct(Guid id);
        ErrorModel CreateProductOption(Guid prodcutid, ProductOption productoption);
        ErrorModel UpdateProductOption(Guid id, ProductOption productoption);
        ErrorModel DeleteProductOption(Guid id);
    }
}
