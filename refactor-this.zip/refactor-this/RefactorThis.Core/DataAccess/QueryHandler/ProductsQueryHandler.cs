﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using RefactorThis.Core.DataAccess.Models;
/// <summary>
/// Class to handle Product table and product option table sql select queries
/// </summary>
namespace RefactorThis.Core.DataAccess.QueryHandler
{
    public class ProductsQueryHandler : IProductsQueryHandler
    {
        private readonly Products _products = null;
        private readonly ProductOptions _productOptions = null;
        public ProductsQueryHandler()
        {
            _products = new Products();
            _productOptions = new ProductOptions();
        }
        protected virtual SqlConnection GetDbConnection()
        {
            return DbHelpers.NewConnection();
        }
        public Products GetAllProducts()
        {
            LoadProducts(null);
            return _products;
        }
        public Products SearchProduct(string name)
        {
            LoadProducts($"where lower(name) like '%{name.ToLower()}%'");
            return _products;
        }

        private void LoadProducts(string where)
        {
            _products.Items = new List<Product>();
            var conn = GetDbConnection();
            var cmd = new SqlCommand($"select id from product {where}", conn);
            conn.Open();

            var rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                var id = Guid.Parse(rdr["id"].ToString());
                _products.Items.Add(GetProduct(id));
            }
        }

        public Product GetProduct(Guid id)
        {
            Product prod = new Product();
            var conn = GetDbConnection();
            var cmd = new SqlCommand($"select * from product where id = '{id}'", conn);
            conn.Open();

            var rdr = cmd.ExecuteReader();
            if (rdr.Read())
            {
                prod.IsNew = false;
                prod.Id = Guid.Parse(rdr["Id"].ToString());
                prod.Name = rdr["Name"].ToString();
                prod.Description = (DBNull.Value == rdr["Description"]) ? null : rdr["Description"].ToString();
                prod.Price = decimal.Parse(rdr["Price"].ToString());
                prod.DeliveryPrice = decimal.Parse(rdr["DeliveryPrice"].ToString());
            }
            
            return prod;
        }

        public ProductOptions GetProductOptions(Guid productId)
        {
            LoadProductOptions($"where productid = '{productId}'");
            return _productOptions;
        }

        public ProductOption GetProductOption(Guid productId, Guid id)
        {
            return GetProductOption(id);
        }

        private void LoadProductOptions(string where)
        {
            _productOptions.Items = new List<ProductOption>();
            var conn = GetDbConnection();
            var cmd = new SqlCommand($"select id from productoption {where}", conn);
            conn.Open();

            var rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                var id = Guid.Parse(rdr["id"].ToString());
                _productOptions.Items.Add(GetProductOption(id));
            }
        }
        private ProductOption GetProductOption(Guid id)
        {
            ProductOption prodoption = new ProductOption();            
            var conn = DbHelpers.NewConnection();
            var cmd = new SqlCommand($"select * from productoption where id = '{id}'", conn);
            conn.Open();

            var rdr = cmd.ExecuteReader();
            if (rdr.Read())
            {
                prodoption.IsNew = false;
                prodoption.Id = Guid.Parse(rdr["Id"].ToString());
                prodoption.ProductId = Guid.Parse(rdr["ProductId"].ToString());
                prodoption.Name = rdr["Name"].ToString();
                prodoption.Description = (DBNull.Value == rdr["Description"]) ? null : rdr["Description"].ToString();
            }

            return prodoption;
        }
    }
}
