﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RefactorThis.Core.DataAccess.Models;

namespace RefactorThis.Core.DataAccess.QueryHandler
{
    public interface IProductsQueryHandler
    {
        Products GetAllProducts();
        Products SearchProduct(string name);
        Product GetProduct(Guid id);
        ProductOptions GetProductOptions(Guid productId);
        ProductOption GetProductOption(Guid productId, Guid id);
    }
}
