﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace RefactorThis.Core.DataAccess
{
    public class DbHelpers
    {       
        private const string ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename={DataDirectory}\Database.mdf;Integrated Security=True";

        public static SqlConnection NewConnection()
        {
            string strconn = string.Empty;
            if (HttpContext.Current != null)
                strconn = ConnectionString.Replace("{DataDirectory}", HttpContext.Current.Server.MapPath("~/App_Data"));
            else
                strconn = ConnectionString.Replace("{DataDirectory}", AppDomain.CurrentDomain.BaseDirectory.Replace("RefactorThis.Tests\\bin\\Debug", "RefactorThis\\App_Data"));// @"D:\MyWorks\RefactorAssessment\refactor-this\RefactorThis\App_Data");
            return new SqlConnection(strconn);
        }
        
    }
}
