﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// Product list model class
/// </summary>
namespace RefactorThis.Core.DataAccess.Models
{
    public class Products
    {
        public List<Product> Items { get; set; }       
    }
}
