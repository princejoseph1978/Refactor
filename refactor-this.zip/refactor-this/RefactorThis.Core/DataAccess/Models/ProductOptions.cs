﻿using System.Collections.Generic;
/// <summary>
/// Product option List model class
/// </summary>
namespace RefactorThis.Core.DataAccess.Models
{
    public class ProductOptions
    {
        public List<ProductOption> Items { get;  set; }       
       
    }
}
