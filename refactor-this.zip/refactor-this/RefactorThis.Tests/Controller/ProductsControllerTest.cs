﻿using System;
using System.Net.Http;
using System.Web.Http;
using AutoFixture;
using AutoFixture.AutoMoq;
using Moq;
using refactor_this.Controllers;
using RefactorThis.Core.DataAccess.Models;
using RefactorThis.Core.DataAccess.QueryHandler;
using RefactorThis.Core.DataAccess.Repository;
using Shouldly;
using Xunit;
/// <summary>
/// Unit test class for products controller usin xunit, autofixure, moq, shouldly
/// </summary>
namespace RefactorThis.Tests.Controller
{
    public class ProductsControllerTest
    {
        private readonly IFixture _fixture;
        private Guid productId = Guid.NewGuid();
        private Guid productOptionId = Guid.NewGuid();
        private string productSearch = "Testproduct";
        public ProductsControllerTest()
        {
            _fixture = new Fixture().Customize(new AutoMoqCustomization());
            _fixture.Behaviors.Remove(new ThrowingRecursionBehavior());
            _fixture.Customize<ProductsControllerTest>(t => t.OmitAutoProperties());
            _fixture.Behaviors.Add(new OmitOnRecursionBehavior(5));
        }
        private IProductsQueryHandler GetProductsQueryHandlerMock()
        {
            var qrhand = new Mock<IProductsQueryHandler>();
            return qrhand.Object;
        }
        private IProductsRepository GetProductsRepositoryMock()
        {
            var repo = new Mock<IProductsRepository>();
            return repo.Object;
        }
        private Products GetListData_Products()
        {
            return _fixture.Create<Products>();
        }
        private Product GetData_ProductSingle()
        {
            return _fixture.Create<Product>();
        }
        private Product CreateData_ProductSingle()
        {
            return _fixture.Create<Product>();
        }
        private ProductOptions GetListData_ProductOptions()
        {
            return _fixture.Create<ProductOptions>();
        }
        private ProductOption GetData_ProductOptionSingle()
        {
            return _fixture.Create<ProductOption>();
        }
        private ProductOption CreateData_ProductOptionSingle()
        {
            return _fixture.Create<ProductOption>();
        }
        [Fact]
        public void ProductsController_GetAllProducts_given_no_param_then_returnallproducts()
        {
            var controller = new ProductsController(GetProductsQueryHandlerMock(), GetProductsRepositoryMock());
            controller.Request = new HttpRequestMessage();
            controller.Configuration = new HttpConfiguration();
            IHttpActionResult result = controller.GetAll();
            result.ShouldNotBeNull();
        }
        [Fact]
        public void ProductsController_SearchProducts_given_search_name_then_returnsearchedproducts()
        {
            var controller = new ProductsController(GetProductsQueryHandlerMock(), GetProductsRepositoryMock());
            controller.Request = new HttpRequestMessage();
            controller.Configuration = new HttpConfiguration();
            IHttpActionResult result = controller.GetAll(productSearch);
            result.ShouldNotBeNull();
        }
        [Fact]
        public void ProductsController_GetProduct_given_product_id_then_returnproduct()
        {
            var controller = new ProductsController(GetProductsQueryHandlerMock(), GetProductsRepositoryMock());
            controller.Request = new HttpRequestMessage();
            controller.Configuration = new HttpConfiguration();
            IHttpActionResult result = controller.GetProduct(productId);
            result.ShouldNotBeNull();
        }
        [Fact]
        public void ProductsController_CreateProduct_given_product_then_returnsuccess()
        {
            var controller = new ProductsController(GetProductsQueryHandlerMock(), GetProductsRepositoryMock());
            controller.Request = new HttpRequestMessage();
            controller.Configuration = new HttpConfiguration();
            IHttpActionResult result = controller.Create(GetData_ProductSingle());
            result.ShouldNotBeNull();
        }
        [Fact]
        public void ProductsController_UpdateProduct_given_product_then_returnsuccess()
        {
            var controller = new ProductsController(GetProductsQueryHandlerMock(), GetProductsRepositoryMock());
            controller.Request = new HttpRequestMessage();
            controller.Configuration = new HttpConfiguration();
            IHttpActionResult result = controller.Update(productId, GetData_ProductSingle());
            result.ShouldNotBeNull();
        }
        [Fact]
        public void ProductsController_DeleteProduct_given_product_id_then_returnsuccess()
        {
            var controller = new ProductsController(GetProductsQueryHandlerMock(), GetProductsRepositoryMock());
            controller.Request = new HttpRequestMessage();
            controller.Configuration = new HttpConfiguration();
            IHttpActionResult result = controller.Delete(productId);
            result.ShouldNotBeNull();
        }

        [Fact]
        public void ProductsController_GetAllProductOptions_given_no_param_then_returnallproducts()
        {
            var controller = new ProductsController(GetProductsQueryHandlerMock(), GetProductsRepositoryMock());
            controller.Request = new HttpRequestMessage();
            controller.Configuration = new HttpConfiguration();
            IHttpActionResult result = controller.GetOptions(productId);
            result.ShouldNotBeNull();
        }       
        [Fact]
        public void ProductsController_GetProductOption_given_product_id_then_returnproduct()
        {
            var controller = new ProductsController(GetProductsQueryHandlerMock(), GetProductsRepositoryMock());
            controller.Request = new HttpRequestMessage();
            controller.Configuration = new HttpConfiguration();
            IHttpActionResult result = controller.GetOption(productId, productOptionId);
            result.ShouldNotBeNull();
        }
        [Fact]
        public void ProductsController_CreateProductOption_given_productoption_then_returnsuccess()
        {
            var controller = new ProductsController(GetProductsQueryHandlerMock(), GetProductsRepositoryMock());
            controller.Request = new HttpRequestMessage();
            controller.Configuration = new HttpConfiguration();
            IHttpActionResult result = controller.CreateOption(productId, GetData_ProductOptionSingle());
            result.ShouldNotBeNull();
        }
        [Fact]
        public void ProductsController_UpdateProductOption_given_productoption_then_returnsuccess()
        {
            var controller = new ProductsController(GetProductsQueryHandlerMock(), GetProductsRepositoryMock());
            controller.Request = new HttpRequestMessage();
            controller.Configuration = new HttpConfiguration();
            IHttpActionResult result = controller.UpdateOption(productOptionId, GetData_ProductOptionSingle());
            result.ShouldNotBeNull();
        }
        [Fact]
        public void ProductsController_DeleteProductOption_given_productoption_id_then_returnsuccess()
        {
            var controller = new ProductsController(GetProductsQueryHandlerMock(), GetProductsRepositoryMock());
            controller.Request = new HttpRequestMessage();
            controller.Configuration = new HttpConfiguration();
            IHttpActionResult result = controller.DeleteOption(productOptionId);
            result.ShouldNotBeNull();
        }
    }
}
