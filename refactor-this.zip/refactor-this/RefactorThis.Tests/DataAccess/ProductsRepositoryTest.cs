﻿using System;
using System.Transactions;
using AutoFixture;
using AutoFixture.AutoMoq;
using Moq;
using RefactorThis.Core.DataAccess.Models;
using RefactorThis.Core.DataAccess.Repository;
using Shouldly;
using Xunit;
/// <summary>
/// Unit test class for Products Repository Handler
/// </summary>
namespace RefactorThis.Tests.Controller
{
    public class ProductsRepositoryTest
    {
        IProductsRepository sut;
        private readonly IFixture _fixture;
        private Guid productId = Guid.NewGuid();
        private Guid productOptionId = Guid.NewGuid();
       
        public ProductsRepositoryTest()
        {
            sut = new ProductsRepository();
            _fixture = new Fixture().Customize(new AutoMoqCustomization());
            _fixture.Behaviors.Remove(new ThrowingRecursionBehavior());
            _fixture.Customize<ProductsRepositoryTest>(t => t.OmitAutoProperties());
            _fixture.Behaviors.Add(new OmitOnRecursionBehavior(5));
        }
       
        private IProductsRepository GetProductsRepositoryMock()
        {
            var repo = new Mock<IProductsRepository>();
            return repo.Object;
        }
     
        private Product CreateData_ProductSingle()
        {
            return _fixture.Create<Product>();
        }       
        private ProductOption CreateData_ProductOptionSingle()
        {
            return _fixture.Create<ProductOption>();
        }
        [Fact]
        public void ProductsRepository_CreateProduct_given_product_then_returnnotnull()
        {
            using (var transaction = new TransactionScope())
            { 
                var result = sut.CreateProduct(CreateData_ProductSingle());
                result.ShouldNotBeNull();
            }
        }
        [Fact]
        public void ProductsRepository_UpdateProduct_given_productid_then_returnnotnull()
        {
            using (var transaction = new TransactionScope())
            {
                var result = sut.UpdateProduct(productId, CreateData_ProductSingle());
                result.ShouldNotBeNull();
            }
        }
        [Fact]
        public void ProductsRepository_DeleteProduct_given_productid_then_returnnotnull()
        {
            using (var transaction = new TransactionScope())
            {
                var result = sut.DeleteProduct(productId);
                result.ShouldNotBeNull();
            }
        }
        [Fact]
        public void ProductsRepository_CreateProductOption_given_productoption_then_returnnotnull()
        {
            using (var transaction = new TransactionScope())
            {
                var result = sut.CreateProductOption(productId, CreateData_ProductOptionSingle());
                result.ShouldNotBeNull();
            }
        }
        [Fact]
        public void ProductsRepository_UpdateProductOption_given_productoptionid_then_returnnotnull()
        {
            using (var transaction = new TransactionScope())
            {
                var result = sut.UpdateProductOption(productOptionId, CreateData_ProductOptionSingle());
                result.ShouldNotBeNull();
            }
        }
        [Fact]
        public void ProductsRepository_DeleteProductOption_given_productoptionid_then_returnnotnull()
        {
            using (var transaction = new TransactionScope())
            {
                var result = sut.DeleteProductOption(productOptionId);
                result.ShouldNotBeNull();
            }
        }
    }
}
