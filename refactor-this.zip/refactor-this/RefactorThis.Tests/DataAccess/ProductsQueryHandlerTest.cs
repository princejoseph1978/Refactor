﻿using System;
using RefactorThis.Core.DataAccess.QueryHandler;
using Shouldly;
using Xunit;
/// <summary>
/// Unit test class for Products QueryHandler
/// </summary>
namespace RefactorThis.Tests.DataAccess
{
    public class ProductsQueryHandlerTest
    {       
        private Guid productId = Guid.NewGuid();
        private Guid optionId = Guid.NewGuid();
        private Guid productOptionId = Guid.NewGuid();
        private string productSearch = "Testproduct";
        IProductsQueryHandler qHandler;

        public ProductsQueryHandlerTest()
        {
            qHandler = new ProductsQueryHandler();            
        }       
        [Fact]
        public void ProductsQueryHandler_GetAll_Given_no_param_then_Return_allproducts()
        {           
            var result = qHandler.GetAllProducts();           
            result.ShouldNotBeNull();
        }
        [Fact]
        public void ProductsQueryHandler_GetProduct_Given_productid_then_Return_notnull()
        {
            var result = qHandler.GetProduct(productId);
            result.ShouldNotBeNull();
        }
        [Fact]
        public void ProductsQueryHandler_SearchProduct_Given_productname_then_Return_notnull()
        {
            var result = qHandler.SearchProduct(productSearch);
            result.ShouldNotBeNull();
        }
        [Fact]
        public void ProductsQueryHandler_GetAllOptions_Given_productid_then_Return_allproducts()
        {
            var result = qHandler.GetProductOptions(productId);
            result.ShouldNotBeNull();
        }
        [Fact]
        public void ProductsQueryHandler_GetProductOption_Given_productid_and_optionid_then_Return_notnull()
        {
            var result = qHandler.GetProductOption(productId,optionId);
            result.ShouldNotBeNull();
        }

    }
}
