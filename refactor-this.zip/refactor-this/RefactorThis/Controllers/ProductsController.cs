﻿using System;
using System.Net;
using System.Web.Http;
using System.Web.Http.Cors;
using refactor_this.Filters;
using RefactorThis.Core.DataAccess.Models;
using RefactorThis.Core.DataAccess.QueryHandler;
using RefactorThis.Core.DataAccess.Repository;
/// <summary>
/// API Controller with Swagger documentation enabled. Swagger documentation example url http://localhost:58123/swagger/
/// JWT token to be added in the Authorization header for accessing the API
/// Token created using a single secret key. Same token can be used for all requests
/// Token to access API:  Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJuYW1lIjoidGVzdHVzZXIiLCJqdGkiOiJlMDkyZmEwOS00MWM3LTRlOTUtOTJlMC03NDIyM2RlOGIxYTYiLCJpYXQiOjE1Mjg0OTY0MTAsImV4cCI6MTUyODUwMDAxMH0.b0iJPqgIDxzUNYEJ5I9RErcdX_ei0Wqvmb2kF5qguLE
/// </summary>
namespace refactor_this.Controllers
{
    //[AuthorizationRequiredAttribute] 
    [RoutePrefix("api/v1/products")]
    //[EnableCors(origins: "*", headers: "*", methods: "*")]
    public class ProductsController : BaseApiController
    {
        private IProductsQueryHandler _productQueryHandler;
        private IProductsRepository _productRepository;

        public ProductsController(IProductsQueryHandler productQueryHandler, IProductsRepository productRepository)
        {
            _productQueryHandler = productQueryHandler;
            _productRepository = productRepository;
        }
      
        [Route("")]
        [HttpGet]
        public IHttpActionResult GetAll(string name = null)
        {
            try
            {
                if (string.IsNullOrEmpty(name))
                    return Ok(_productQueryHandler.GetAllProducts());
                else
                    return Ok(_productQueryHandler.SearchProduct(name));
            }
            catch (Exception ex)
            {
                return CreateCustomErrorResponseMessage(ex.Message);
            }
        }

        [Route("{id}")]
        [HttpGet]
        public IHttpActionResult GetProduct(Guid id)
        {
            try
            {
                var product = _productQueryHandler.GetProduct(id);
                if (product != null && product.IsNew)
                    return CreateCustomErrorResponseMessage("Product not found");

                return Ok(product);
            }
            catch (Exception ex)
            {
                return CreateCustomErrorResponseMessage(ex.Message);
            }
        }

        [Route("")]
        [HttpPost]
        public IHttpActionResult Create(Product product)
        {
            try
            {
                var result = _productRepository.CreateProduct(product);

                if (result.Code > 0)
                    return CreateCustomErrorModel(result);
                else
                    return Ok(result);
            }
            catch (Exception ex)
            {
                return CreateCustomErrorResponseMessage(ex.Message);
            }            
        }

        [Route("{id}")]
        [HttpPut]
        public IHttpActionResult Update(Guid id, Product product)
        {
            try
            {
                var result = _productRepository.UpdateProduct(id, product);
                if(result.Code > 0)
                    return CreateCustomErrorModel(result);
                else
                    return Ok(result);
            }
            catch (Exception ex)
            {
                return CreateCustomErrorResponseMessage(ex.Message);
            }
        }

        [Route("{id}")]
        [HttpDelete]
        public IHttpActionResult Delete(Guid id)
        {
            try
            {               
                var result = _productRepository.DeleteProduct(id);
                if (result.Code > 0)
                    return CreateCustomErrorModel(result);
                else
                    return Ok(result);
            }
            catch (Exception ex)
            {
                return CreateCustomErrorResponseMessage(ex.Message);
            }
        }

        [Route("{productId}/options")]
        [HttpGet]
        public IHttpActionResult GetOptions(Guid productId)
        {
            try
            {
                return Ok(_productQueryHandler.GetProductOptions(productId));
            }
            catch (Exception ex)
            {
                return CreateCustomErrorResponseMessage(ex.Message);
            }
        }

        [Route("{productId}/options/{id}")]
        [HttpGet]
        public IHttpActionResult GetOption(Guid productId, Guid id)
        {
            try
            {
                var option = _productQueryHandler.GetProductOption(productId, id);
                if (option != null && option.IsNew)
                    return CreateCustomErrorResponseMessage("Product option not found");

                return Ok(option);
            }
            catch (Exception ex)
            {
                return CreateCustomErrorResponseMessage(ex.Message);
            }           
        }

        [Route("{productId}/options")]
        [HttpPost]
        public IHttpActionResult CreateOption(Guid productId, ProductOption option)
        {
            try
            {
                var result = _productRepository.CreateProductOption(productId, option);

                if (result.Code > 0)
                    return CreateCustomErrorModel(result);
                else
                    return Ok(result);
            }
            catch (Exception ex)
            {
                return CreateCustomErrorResponseMessage(ex.Message);
            }
        }

        [Route("{productId}/options/{id}")]
        [HttpPut]
        public IHttpActionResult UpdateOption(Guid id, ProductOption option)
        {
            try
            {
                var result = _productRepository.UpdateProductOption(id, option);
                if (result.Code > 0)
                    return CreateCustomErrorModel(result);
                else
                    return Ok(result);
            }
            catch (Exception ex)
            {
                return CreateCustomErrorResponseMessage(ex.Message);
            }

        }

        [Route("{productId}/options/{id}")]
        [HttpDelete]
        public IHttpActionResult DeleteOption(Guid id)
        {
            try
            {
                var result = _productRepository.DeleteProductOption(id);
                if (result.Code > 0)
                    return CreateCustomErrorModel(result);
                else
                    return Ok(result);
            }
            catch (Exception ex)
            {
                return CreateCustomErrorResponseMessage(ex.Message);
            }
        }
    }
}
