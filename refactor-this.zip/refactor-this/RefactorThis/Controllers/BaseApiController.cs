﻿using System.Collections.Generic;
using System.Net;
using System.Web.Http;
using RefactorThis.Core.DataAccess.Models;

namespace refactor_this.Controllers
{
    public class BaseApiController : ApiController
    {

        /// <summary>
        /// Accepts Error Model.
        /// </summary>
        /// <param name="error"></param>
        /// <returns></returns>
        protected IHttpActionResult CreateCustomErrorModel(ErrorModel error)
        {
            error.Description = error.Description ?? HttpStatusCode.NotFound.ToString();
            return Content(HttpStatusCode.NotFound, error);
        }
        /// <summary>
        /// Accepts error message
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        protected IHttpActionResult CreateCustomErrorResponseMessage(string message, HttpStatusCode statusCode = HttpStatusCode.NotFound)
        {
            ErrorModel model = new ErrorModel() { Code = (int)statusCode, Message = message, Description = statusCode.ToString() };
            return Content(statusCode, model);
        }
        /// <summary>
        /// Validatin error message
        /// </summary>
        /// <param name="validationMessages"></param>
        /// <returns></returns>
        protected IHttpActionResult CreateBadResponseMessage(List<ErrorModel> validationMessages)
        {
            return Content(HttpStatusCode.BadRequest, validationMessages);
        }
    }
}