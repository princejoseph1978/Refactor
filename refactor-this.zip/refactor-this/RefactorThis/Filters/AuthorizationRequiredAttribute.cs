﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Claims;
using System.Security.Cryptography;
using System.ServiceModel.Security.Tokens;
using System.Text;
using System.Web;
using System.Web.Http;
using System.Web.Http.Controllers;
using Microsoft.IdentityModel.Tokens;
using RefactorThis.Core.DataAccess.Models;
using RefactorThis.Core.DataAccess.Repository;
/// <summary>
/// JWT token based authorization filter class
/// </summary>
namespace refactor_this.Filters
{
    public class AuthorizationRequiredAttribute : AuthorizeAttribute
    {
        IProductsRepository _productsRepository;
        private const string jwtKey = "db3OIsj+BXE9NZDy0t8W3TcNekrF+2d/1sFnWG4HnV8TZY30iTOdtVWJG8abWvB1GlOgJuQZdcF2Luqm/hccMw==";
        public AuthorizationRequiredAttribute()
            : this(new ProductsRepository())
        { }
        public AuthorizationRequiredAttribute(IProductsRepository productsRepository)
        {
            _productsRepository = productsRepository;
        }

        public override void OnAuthorization(HttpActionContext filterContext)
        {
            try
            {
                string token;
                var request = filterContext.Request;
                if (TryRetrieveToken(request, out token))
                {
                    ClaimsPrincipal principal = ValidateJwtToken(token);
                    if (!principal.Identity.IsAuthenticated)
                    {
                        filterContext.Response = CreateResponse(HttpStatusCode.Unauthorized, "UnAuthorized", "Authorization failed");
                    }
                }
                else
                {
                    filterContext.Response = CreateResponse(HttpStatusCode.BadRequest, "BadRequest", "Unable to process the request");
                }
            }
            catch(Exception ex)
            {
                filterContext.Response = CreateResponse(HttpStatusCode.BadRequest, "BadRequest", ex.Message);
            }
        }

        private HttpResponseMessage CreateResponse(HttpStatusCode statusCode, string message, string description)
        {
            var error = new ErrorModel()
            {
                Code = (int)HttpStatusCode.Unauthorized,
                Message = message,
                Description = description
            };
            HttpRequestMessage request = new HttpRequestMessage();
            request.Properties.Add(System.Web.Http.Hosting.HttpPropertyKeys.HttpConfigurationKey, new HttpConfiguration());
            HttpResponseMessage response = request.CreateResponse(statusCode, error);
            return response;
        }
        private static ClaimsPrincipal ValidateJwtToken(string token)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var jwtToken = tokenHandler.ReadToken(token) as JwtSecurityToken;
            if (jwtToken == null)
                return null;

            HMACSHA256 hmac = new HMACSHA256(Encoding.ASCII.GetBytes(jwtKey));           
            TokenValidationParameters validationParams =
                new TokenValidationParameters()
                {                   
                    ValidateIssuer = false,
                    ValidateAudience = false,
                    IssuerSigningKey = new SymmetricSecurityKey(hmac.Key),
                    ValidateLifetime = false
                };
            SecurityToken validatedToken;
            return tokenHandler.ValidateToken(token, validationParams, out validatedToken);
        }

        private static bool TryRetrieveToken(HttpRequestMessage request, out string token)
        {
            token = null;
            bool isValid = false;
            var typeOfToken = "Authorization";
            var authorizationHeader = "Bearer ";
            IEnumerable<string> authorizationHeaders;
            if (request.Headers.TryGetValues(typeOfToken, out authorizationHeaders) && authorizationHeaders.Count() == 1)
            {
                var authToken = authorizationHeaders.ElementAt(0);
                if (authToken.StartsWith(authorizationHeader))
                {
                    token = authToken.Substring(authorizationHeader.Length).Length > 0 ? authToken.Substring(authorizationHeader.Length) : null;
                    isValid = true;
                }
            }
            return isValid;
        }
        private static byte[] GetBytes(string input)
        {
            var bytes = new byte[input.Length * sizeof(char)];
            Buffer.BlockCopy(input.ToCharArray(), 0, bytes, 0, bytes.Length);
            return bytes;
        }

    }
}