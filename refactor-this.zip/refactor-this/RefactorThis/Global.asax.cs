﻿using System.Reflection;
using System.Web.Http;
using System.Web.Routing;
using Autofac;
using Autofac.Integration.WebApi;
using RefactorThis.Core.DataAccess.QueryHandler;
using RefactorThis.Core.DataAccess.Repository;

namespace refactor_this
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            GlobalConfiguration.Configure(WebApiConfig.Register);
            RegisterComponents();
        }

        private void RegisterComponents()
        {
            var builder = new ContainerBuilder();
            builder.RegisterApiControllers(Assembly.GetExecutingAssembly()); //Register WebApi Controllers
            builder.RegisterType<ProductsRepository>().As<IProductsRepository>().InstancePerRequest();
            builder.RegisterType<ProductsQueryHandler>().As<IProductsQueryHandler>().InstancePerRequest();
            var container = builder.Build();
            GlobalConfiguration.Configuration.DependencyResolver = new AutofacWebApiDependencyResolver((IContainer)container); //Set the WebApi DependencyResolver
        }
    }
}
